import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const search = searchParams.get('search') || '';
    const tanggal = searchParams.get('tanggal'); // Filter by specific date

    const skip = (page - 1) * limit;

    // Build where clause
    const where: Record<string, unknown> = {};
    
    if (search) {
      where.namaSekolah = { contains: search };
    }
    
    // Filter by specific date
    if (tanggal) {
      const date = new Date(tanggal);
      const startOfDay = new Date(date.setHours(0, 0, 0, 0));
      const endOfDay = new Date(date.setHours(23, 59, 59, 999));
      
      where.tanggal = {
        gte: startOfDay,
        lte: endOfDay,
      };
    }

    const [data, total] = await Promise.all([
      db.distribusi.findMany({
        where,
        orderBy: { tanggal: 'desc' },
        skip: tanggal ? 0 : skip, // Don't paginate when filtering by date
        take: tanggal ? limit : limit,
      }),
      db.distribusi.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      data,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching distribusi:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch distribusi data' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { 
      namaSekolah,
      klsAL, klsAP, klsBL, klsBP,
      kls1L, kls1P, kls2L, kls2P, kls3L, kls3P,
      kls4L, kls4P, kls5L, kls5P, kls6L, kls6P,
      kls7L, kls7P, kls8L, kls8P, kls9L, kls9P,
      kls10L, kls10P, kls11L, kls11P, kls12L, kls12P,
      kepsekL, kepsekP, guruL, guruP, tendikL, tendikP, nonTendikL, nonTendikP,
      ujiOrganoleptik,
      tanggal
    } = body;

    if (!namaSekolah) {
      return NextResponse.json(
        { success: false, error: 'Nama sekolah harus diisi' },
        { status: 400 }
      );
    }

    // Calculate jumlah (total siswa + guru)
    const jumlahSiswa = 
      (parseInt(klsAL) || 0) + (parseInt(klsAP) || 0) +
      (parseInt(klsBL) || 0) + (parseInt(klsBP) || 0) +
      (parseInt(kls1L) || 0) + (parseInt(kls1P) || 0) +
      (parseInt(kls2L) || 0) + (parseInt(kls2P) || 0) +
      (parseInt(kls3L) || 0) + (parseInt(kls3P) || 0) +
      (parseInt(kls4L) || 0) + (parseInt(kls4P) || 0) +
      (parseInt(kls5L) || 0) + (parseInt(kls5P) || 0) +
      (parseInt(kls6L) || 0) + (parseInt(kls6P) || 0) +
      (parseInt(kls7L) || 0) + (parseInt(kls7P) || 0) +
      (parseInt(kls8L) || 0) + (parseInt(kls8P) || 0) +
      (parseInt(kls9L) || 0) + (parseInt(kls9P) || 0) +
      (parseInt(kls10L) || 0) + (parseInt(kls10P) || 0) +
      (parseInt(kls11L) || 0) + (parseInt(kls11P) || 0) +
      (parseInt(kls12L) || 0) + (parseInt(kls12P) || 0);

    const jumlahGuru = 
      (parseInt(kepsekL) || 0) + (parseInt(kepsekP) || 0) +
      (parseInt(guruL) || 0) + (parseInt(guruP) || 0) +
      (parseInt(tendikL) || 0) + (parseInt(tendikP) || 0) +
      (parseInt(nonTendikL) || 0) + (parseInt(nonTendikP) || 0);

    const distribusi = await db.distribusi.create({
      data: {
        namaSekolah,
        klsAL: parseInt(klsAL) || 0,
        klsAP: parseInt(klsAP) || 0,
        klsBL: parseInt(klsBL) || 0,
        klsBP: parseInt(klsBP) || 0,
        kls1L: parseInt(kls1L) || 0,
        kls1P: parseInt(kls1P) || 0,
        kls2L: parseInt(kls2L) || 0,
        kls2P: parseInt(kls2P) || 0,
        kls3L: parseInt(kls3L) || 0,
        kls3P: parseInt(kls3P) || 0,
        kls4L: parseInt(kls4L) || 0,
        kls4P: parseInt(kls4P) || 0,
        kls5L: parseInt(kls5L) || 0,
        kls5P: parseInt(kls5P) || 0,
        kls6L: parseInt(kls6L) || 0,
        kls6P: parseInt(kls6P) || 0,
        kls7L: parseInt(kls7L) || 0,
        kls7P: parseInt(kls7P) || 0,
        kls8L: parseInt(kls8L) || 0,
        kls8P: parseInt(kls8P) || 0,
        kls9L: parseInt(kls9L) || 0,
        kls9P: parseInt(kls9P) || 0,
        kls10L: parseInt(kls10L) || 0,
        kls10P: parseInt(kls10P) || 0,
        kls11L: parseInt(kls11L) || 0,
        kls11P: parseInt(kls11P) || 0,
        kls12L: parseInt(kls12L) || 0,
        kls12P: parseInt(kls12P) || 0,
        kepsekL: parseInt(kepsekL) || 0,
        kepsekP: parseInt(kepsekP) || 0,
        guruL: parseInt(guruL) || 0,
        guruP: parseInt(guruP) || 0,
        tendikL: parseInt(tendikL) || 0,
        tendikP: parseInt(tendikP) || 0,
        nonTendikL: parseInt(nonTendikL) || 0,
        nonTendikP: parseInt(nonTendikP) || 0,
        ujiOrganoleptik: parseInt(ujiOrganoleptik) || 0,
        jumlah: jumlahSiswa + jumlahGuru + (parseInt(ujiOrganoleptik) || 0),
        tanggal: tanggal ? new Date(tanggal) : new Date(),
      },
    });

    return NextResponse.json({
      success: true,
      data: distribusi,
      message: 'Data distribusi berhasil ditambahkan',
    });
  } catch (error) {
    console.error('Error creating distribusi:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create distribusi' },
      { status: 500 }
    );
  }
}
